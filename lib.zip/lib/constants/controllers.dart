import 'package:flutter_web_course/controllers/menu_controller.dart';
import 'package:flutter_web_course/controllers/navigation_controller.dart';
// import 'package:flutter/material.dart';

MenuController menuController = MenuController.instance;
NavigationController navigationController = NavigationController.instance;
