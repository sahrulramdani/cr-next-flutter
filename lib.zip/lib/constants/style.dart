import 'package:flutter/material.dart';

//Warna Aktif
Color light = const Color(0xFFF7F8FC);
Color lightGrey = const Color(0xFFA4A6B3);
Color dark = const Color(0xFF363740);
Color active = const Color(0xFF3C19C0);
Color myBlue = const Color.fromARGB(255, 14, 116, 199);
Color bgBlue = const Color.fromARGB(255, 241, 242, 255);
Color myGrey = Colors.grey[700];
//Token

String kodeToken = "";
String namaUser = "";
String fotoUser = "";

bool enableForm = false;

//Url Aplikasi
String urlAddress = "http://localhost:3000";
// String urlAddress = "http://202.78.195.175:4000";
