import 'package:flutter/foundation.dart';

// AGENCY
String fotoAgency = "";
String fotoAgencyBase = "";
Uint8List fotoAgencyByte;

String fotoKtpAgency = "";
String fotoKtpAgencyBase = "";
Uint8List fotoKtpAgencyByte;

String fotoCalonAgen = "";
String ktpCalonAgen = "";

// JAMAAH
String fotoJamaah = "";
String fotoJamaahBase = "";
Uint8List fotoJamaahByte;

String fotoKtpJamaah = "";
String fotoKtpJamaahBase = "";
Uint8List fotoKtpJamaahByte;
